
from halo import Halo
from termcolor import colored
import time
from simple_term_menu import TerminalMenu


from pprint import pprint
from mitrecve import crawler

import nmap
import socket
from termcolor import colored





min_port = 1 
max_port = 4000  
opens = ""
def port_sca(ip):
	global opens
	for port in range(min_port, max_port):
	    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	    sock.settimeout(1)
	    result = sock.connect_ex((ip, port))
	    if result == 0:
	        
	        if opens == "":
	        	
	        	opens=str(port)
	        	
	        else:
	        	opens = str(opens)+','+str(port)
	    sock.close()
	return opens






def exec(ip,opens):
	nport = opens
	if opens == "":
		print("no open ports aviable Exiting")
		exit()
	nm = nmap.PortScanner()


	nm.scan(hosts=ip, arguments='-sV -p '+nport)


	for port in nm[ip]['tcp']:
	    if nm[ip]['tcp'][port]['state'] == 'open':
	        service = nm[ip]['tcp'][port]['name']
	        version = nm[ip]['tcp'][port]['version']
	        print("\n"+colored("❮  ",'red')+ colored(f"open port {port}  ","blue") +  colored(f" running {service}","yellow") + colored(version,"yellow")+colored("  ❯",'red'))
	        cve_simple = crawler.get_main_page(f"{service} {version}") 
	        with open(service, mode='w') as ws:
	            for x,y in cve_simple.items():
	                ws.write(f"\n \n{str(y)}")
	            ws.write("\n \n \n Created By Anania belay")    
	print(colored("\n File write Sucess ℹ️", "red"))		
def main():
	terminal_menu = TerminalMenu([" Local host Scan", " Scan any Host","Details about Hscan"])
	choice_index = terminal_menu.show()



	if choice_index == 0:
		
		run = Halo(text='Getting ready materials',text_color='blue', spinner='dots')
		run.start()
		time.sleep(2)
		run.succeed('It is ready')
		re = port_sca("127.0.0.1")
		run = Halo(text='Scanning Hosts',text_color='blue', spinner='dots')
		run.start()
		time.sleep(3)
		run.succeed('Scan Sucess')
		exec("127.0.0.1",re)

	if choice_index ==1:
		run = Halo(text='Getting Things ready',text_color='blue', spinner='dots')
		run.start()
		time.sleep(3)
		run.color = 'red'
		run.info('Make Sure the firewall is Turned of on remote host')
		time.sleep(2)

		run.succeed('Initialized')		
		run.clear()
		tyoe = input(colored("Input the ip address of the host: ","yellow"))
		re = port_sca(tyoe)
		exec(tyoe,re)
	if choice_index == 2:
		print(colored("It was developed for scanning vulnerability in hosts and to exploit that vulnerability Version 1.0.0 \n Developed by Anania Belay @2022",'red'))	
		exit()
	while True:
		main()	

main()